import { emailQueue } from "../queue/queue.js";
import logger from "../utils/logger.js";
import { EmailUtils } from "../utils/email.utils.js";
import { QUEUE_JOBS } from "../constants/queue-jobs.constant.js";
import { EmailRepository } from "../repositories/email.repository.js";

const emailUtils = new EmailUtils();
const emailRepository = new EmailRepository();

export async function startWorker() {
  try {
    registerProcessors();
  } catch (error) {
    console.error("Worker startup failed", error);
    process.exit(1);
  }
}
async function registerProcessors() {

  emailQueue.process("welcome-email", async (job) => {
    const { email, url } = job.data;
    logger.info(`Processing welcome email for ${email}`);
    await emailUtils.sendWelcomeEmail(email, url);
  });

  emailQueue.process("otp-email", async (job) => {
    const { email, otp } = job.data;
    console.log("otp email job data", job.data);
    logger.info(`Processing otp email for ${email}`);
    await emailUtils.sendOTPEmail(email, otp);
  });

  emailQueue.process("account-creation-email", async (job) => {
    const { accountEmail, accountName } = job.data;
    logger.info(`Processing account creation email for ${accountEmail}`);
    await emailUtils.sendAccountCreationEmail(accountEmail, accountName);
  });

  emailQueue.process("campaign-email", async (job) => {
    const { to, name, subject, html, fromEmail } = job.data;

    const personalizedHtml = html.replace("{{name}}", name || "there");

    await emailUtils.sendEmail(
      to,
      subject,
      personalizedHtml,
      undefined,
      fromEmail,
    );
  });

  emailQueue.process("send-email-activity",async (job) => {
    console.log("Job data",job.data)
      const { emailActivityId, to, name, subject, html, fromEmail, } = job.data;

    try {
      const personalizedHtml = html.replace("{{name}}", name || "there");

        // send email
        const result = await emailUtils.sendEmail(to, subject, personalizedHtml, undefined, fromEmail);
        console.log("send email result",result)
        // update DB success
        console.log("email activity id",emailActivityId);
        const messageId=result?.messageId??"";
        console.log("Messageid",messageId)
        await emailRepository.updateEmailStatus(emailActivityId,"sent",messageId,null);

      } catch (error: any) {
        console.log("Error:",error)

        // update DB failed
        await emailRepository.updateEmailStatus(emailActivityId,"faild","",error);

        throw error;
      }
  });

  emailQueue.process(QUEUE_JOBS.LEAD_NOTIFICATION_EMAIL, async (job) => {
    const { email, lead } = job.data;

    logger.info(`Processing lead notification email for ${email}`);
    await emailUtils.sendLeadAcknowledgementEmail(email, lead);
  });


  emailQueue.process(QUEUE_JOBS.LEAD_ACKNOWLEDGEMENT_EMAIL, async (job) => {
    const { email, lead } = job.data;

    logger.info(`Processing lead acknowledgement email for ${email}`);
    await emailUtils.sendLeadAcknowledgementEmail(email, lead);
  });

  emailQueue.process(QUEUE_JOBS.SEND_ONBOARDING_EMAIL, async (job) => {
    const {
      organizationName,
      firstName,
      lastName,
      email,
      dashboardUrl,
      supportEmail,
      createdAt,
      year,
    } = job.data;
    await emailUtils.sendOnboardingSuccessEmail({
      organizationName,
      firstName,
      lastName,
      email,
      dashboardUrl,
      supportEmail,
      createdAt,
      year,
    });
  });

  emailQueue.process(QUEUE_JOBS.SEND_TASK_ASSIGNED_EMAIL, async (job) => {
    const { email, task } = job.data;
    await emailUtils.sendTaskAssignedEmail(email, task);
    // await emailUtils.sendEmail(
    //   email,
    //   `New Task Assigned: ${task?.taskTitle}`,
    //   `New Task Assigned: ${task?.taskTitle}`,
    // );
  });

  emailQueue.process(QUEUE_JOBS.SEND_LEAD_ASSIGNED_EMAIL, async (job) => {
    const { email, lead } = job.data;
    await emailUtils.sendLeadAssignedEmail(email, lead);
  });

  emailQueue.process(QUEUE_JOBS.EMAIL_CAMPAIGN_PREPARE, 1, async (job) => {
    const { campaignId } = job.data;
    logger.info("Preparing email campaign", { campaignId, jobId: job.id });
    const { emailMarketingService } = await import(
      "../services/email-marketing.service.js"
    );
    await emailMarketingService.prepareAndSend(campaignId);
  });

  emailQueue.process(QUEUE_JOBS.EMAIL_CAMPAIGN_SEND_BATCH, 1, async (job) => {
    const { campaignId, recipientIds } = job.data;
    const { emailMarketingService } = await import(
      "../services/email-marketing.service.js"
    );
    await emailMarketingService.sendBatch(campaignId, recipientIds);
  });

  emailQueue.process(QUEUE_JOBS.WHATSAPP_CAMPAIGN_PREPARE, 1, async (job) => {
    const { campaignId } = job.data;
    logger.info("Preparing WhatsApp campaign", { campaignId, jobId: job.id });
    const { whatsappBroadcastService } = await import(
      "../modules/whatsapp/broadcast/services/whatsapp-broadcast.service.js"
    );
    await whatsappBroadcastService.prepareAndSend(campaignId);
  });

  emailQueue.process(QUEUE_JOBS.WHATSAPP_CAMPAIGN_SEND_BATCH, 1, async (job) => {
    const { campaignId, recipientIds } = job.data;
    const { whatsappBroadcastService } = await import(
      "../modules/whatsapp/broadcast/services/whatsapp-broadcast.service.js"
    );
    await whatsappBroadcastService.sendBatch(campaignId, recipientIds);
  });
}