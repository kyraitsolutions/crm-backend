import { HttpError } from "../utils/http.error.js";
import mongoose, { ClientSession } from "mongoose";
import { RoleResponseDto, UpdateRoleDto } from "../dtos/rbac.dto.js";
import { RbacRepository } from "../repositories/rbac.repository.js";
import {
  NOT_ALLOWED_PERMISSIONS_ACCOUNT_MANGER,
  ROLES,
} from "../config/permissions.js";
import { TRole } from "../types/roles-permissions.type.js";
import {
  TApiResponse,
  TPaginatedResponse,
} from "../types/api-response.type.js";
import { ActivityLogService } from "./activityLog.service.js";

export class RbacService {
  private activityLogService = new ActivityLogService();
  constructor(private rbacRepo: RbacRepository) {}

  // ROLES RELATED METHODS

  // create default roles and permissions
  async createDefaultRolesAndPermissions(
    orgId: string,
    session: ClientSession,
  ) {
    const roles = await this.rbacRepo.createRoles(
      [
        {
          name: ROLES.OWNER,
          organizationId: orgId,
          isSystemRole: true,
          level: 100,
        },
        {
          name: ROLES.ADMIN,
          organizationId: orgId,
          isSystemRole: true,
          level: 75,
        },
        {
          name: ROLES.ACCOUNT_MANAGER,
          organizationId: orgId,
          isSystemRole: true,
          level: 50,
        },
      ],
      session,
    );

    const permissions = await this.rbacRepo.getAllPermissions();
    const adminRole = roles.find((r) => r.name === ROLES.ADMIN)!;
    const accountManagerRole = roles.find(
      (r) => r.name === ROLES.ACCOUNT_MANAGER,
    );

    await this.rbacRepo.createRolePermissions(
      permissions.map((p) => ({
        roleId: adminRole.id,
        permissionId: p.id,
      })),
      session,
    );

    const accountPermissions = permissions.filter(
      (p) => !NOT_ALLOWED_PERMISSIONS_ACCOUNT_MANGER.includes(p.key),
    );

    await this.rbacRepo.createRolePermissions(
      accountPermissions.map((p) => ({
        roleId: accountManagerRole?.id,
        permissionId: p.id,
      })),
      session,
    );

    return roles;
  }

  // create custom role
  async createCustomRole(data: {
    roleName: string;
    permissions: string[];
    organizationId: string;
  }): Promise<
    TApiResponse<Pick<RoleResponseDto, "id" | "name" | "isSystemRole">>
  > {
    const session = await mongoose.startSession();

    try {
      session.startTransaction();
      const { roleName, permissions, organizationId } = data;

      const isRoleNameExists = await this.rbacRepo.getRoleByOrgIdAndName(
        organizationId,
        roleName,
      );

      if (isRoleNameExists) throw HttpError.conflict("Role name already exists");

      // 1️⃣ Create Role
      const [role] = await this.rbacRepo.createRoles(
        [
          {
            name: roleName.toUpperCase(),
            organizationId,
            level: 25,
            isSystemRole: false,
          },
        ],
        session,
      );

      // 2️⃣ Get Permission Docs
      const permissionDocs =
        await this.rbacRepo.getPermissionsByKeys(permissions);

      if (permissionDocs.length !== permissions.length) {
        throw HttpError.badRequest("Invalid permissions");
      }

      // 3️⃣ Create RolePermissions
      const rolePermissions = permissionDocs.map((p) => ({
        roleId: role.id.toString(),
        permissionId: p.id,
      }));

      await this.rbacRepo.createRolePermissions(rolePermissions, session);

      await session.commitTransaction();

      await this.activityLogService.logCreate({
        organizationId,
        entityType: "role",
        entityId: String(role._id),
        actor: { type: "user", name: "" },
        metadata: { roleName: role.name, permissions },
      });

      return {
        doc: {
          id: role._id,
          name: role.name,
          isSystemRole: role.isSystemRole,
        },
      };
    } catch (error) {
      console.log(error);
      await session.abortTransaction();
      throw error;
    } finally {
      session.endSession();
    }
  }

  // get single role by id
  async getRoleById(roleId: string) {
    const role = await this.rbacRepo.getRoleById(roleId);
    if (!role) return null;
    return new RoleResponseDto(role);
  }
  // get single role by org id and name
  async getRoleByOrgIdAndName(
    orgId: string,
    name: string,
  ): Promise<RoleResponseDto | null> {
    const role = await this.rbacRepo.getRoleByOrgIdAndName(orgId, name);

    if (!role) return null;
    return new RoleResponseDto(role);
  }
  // get all roles of organization
  async getRolesByOrganization(
    orgId: string,
    currentRole?: TRole,
  ): Promise<TPaginatedResponse<RoleResponseDto>> {
    const roles = await this.rbacRepo.getRolesByOrganization(
      orgId,
      currentRole?.level,
    );

    return {
      docs: roles.map((r) => new RoleResponseDto(r)),
    };
  }

  async updateRole(
    roleId: string,
    data: UpdateRoleDto,
  ): Promise<TApiResponse<{ id: string }>> {
    const session = await mongoose.startSession();

    try {
      session.startTransaction();
      const { name, permissions, organizationId } = data;

      // 1️⃣ Update role name (if provided)
      if (name) {
        const existingRole = await this.rbacRepo.getRoleByOrgIdAndName(
          organizationId,
          name,
        );

        if (existingRole && existingRole.id !== roleId) {
          throw HttpError.conflict("Role name already exists");
        }

        await this.rbacRepo.updateRoleById(
          roleId,
          { name: name.toUpperCase(), organizationId },
          session,
        );
      }

      // 2️⃣ Update permissions (if provided)
      if (permissions) {
        // get permission docs
        if (!permissions.length) throw HttpError.badRequest("Invalid permissions");

        const permissionDocs =
          await this.rbacRepo.getPermissionsByKeys(permissions);

        if (permissionDocs.length !== permissions.length) {
          throw HttpError.badRequest("Invalid permissions");
        }

        await this.rbacRepo.deleteRolePermissions(roleId, session);

        const rolePermissions = permissionDocs.map((p) => ({
          roleId,
          permissionId: p.id,
        }));

        await this.rbacRepo.createRolePermissions(rolePermissions, session);
      }

      await session.commitTransaction();
      await this.activityLogService.logUpdate({
        oldDoc: { name: undefined, permissions: undefined },
        newDoc: { name, permissions },
        organizationId,
        entityType: "role",
        entityId: roleId,
        actor: { type: "user", name: "" },
        metadata: { roleName: name },
      });
      return {
        doc: {
          id: roleId,
        },
      }; // return updated role with permissions
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      session.endSession();
    }
  }

  // delete role by id
  async deleteRole(roleId: string): Promise<TApiResponse<{ id: string }>> {
    const session = await mongoose.startSession();
    try {
      session.startTransaction();

      const role = await this.rbacRepo.getRoleById(roleId);
      if (!role) throw HttpError.notFound("Role not found");

      const deletedRole = await this.rbacRepo.deleteRoleById(roleId, session);
      await this.rbacRepo.deleteRolePermissions(roleId, session);

      console.log(deletedRole);
      await session.commitTransaction();

      await this.activityLogService.logDelete({
        organizationId: String((role as any)?.organizationId || ""),
        entityType: "role",
        entityId: roleId,
        actor: { type: "user", name: "" },
        metadata: { roleName: (role as any)?.name },
        deletedData: { name: (role as any)?.name },
      });

      return {
        doc: {
          id: deletedRole.id,
        },
      };
    } catch (error) {
      await session.abortTransaction();
      throw error;
    }
  }
  // PERMISSIONS RELATED METHODS
  async getPermissionsByRole(
    roleId: string,
  ): Promise<TPaginatedResponse<string>> {
    const role = await this.rbacRepo.getRoleById(roleId);
    if (!role) throw HttpError.notFound("Role not found");

    const permissions = await this.rbacRepo.getPermissionsByRole(roleId);

    return {
      docs: permissions,
    };
  }
}
