import AutomationRepository from "../repositories/automation.repository.js";
import ActionExecutor from "./action-executor.service.js";
import ConditionEvaluator from "./condition-evaluator.service.js";

export class AutomationEngine {
  private repository = new AutomationRepository();
  private conditionEvaluator = new ConditionEvaluator();
  private actionExecutor = new ActionExecutor();

  async process(event: any) {
    const automations = await this.repository.findByTrigger(
      event.accountId,
      event.trigger,
    );


    console.log("Automations found for trigger", automations);
    for (const automation of automations) {
      const matched = this.conditionEvaluator.evaluate(
        automation.conditions,
        event.payload,
      );

      if (!matched) {
        console.log("Condition not matched for automation", automation._id);
        continue;
      }

      const eventDataPayload = {
        ...event.payload,
        automationId: automation._id,
        automationName: automation.name,
      };

      await this.actionExecutor.execute(automation.actions, eventDataPayload);
    }
  }
}
