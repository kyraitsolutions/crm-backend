import { HttpError } from "../utils/http.error.js";
import mongoose, { ClientSession } from "mongoose";
import {
  CreateUserDto,
  RegisterDto,
  UserDto,
  UserResponseDto,
} from "../dtos/index.js";
import { CreateUserProfileDto } from "../dtos/userprofile.dto.js";
import { Plan } from "../models/subscription.model.js";
import { PLAN_CODE } from "../constants/subscription.constant.js";
import { UserRepository } from "../repositories/user.repository.js";
import { UserProfileRepository } from "../repositories/userprofile.repository.js";
import { TGoogleUser, TUser, TUserLogin } from "../types/index.js";
import { JwtUtil, PasswordUtil } from "../utils/index.js";
import { SubscriptionRepository } from "./../repositories/subscription.repository.js";
import { EmailService } from "./email.service.js";
import { otpService } from "../container.js";
import logger from "../utils/logger.js";

export class UserService {
  constructor(
    private userRepository: UserRepository,
    private userProfileRepository: UserProfileRepository,
    private subscriptionRepository: SubscriptionRepository,
    private emailService: EmailService,
  ) {}

  async register(dto: RegisterDto): Promise<TUser> {
    const session = await mongoose.startSession();

    try {
      session.startTransaction();
      const existingUser = await this.userRepository.findByEmail(dto.email);

      if (existingUser) {
        throw HttpError.conflict("User with this email already exists");
      }

      const hashedPassword = await PasswordUtil.hash(dto?.password as string);

      // find role of Admin
      const role = await this.userRepository.findRole("ADMIN");

      // 3. New user → create user
      const userData = {
        email: dto.email,
        password: hashedPassword,
        role: role?._id,
      };

      // 4. Create user
      const userDataPayloadDto = new CreateUserDto(userData);
      const newUser = await this.userRepository.create(
        userDataPayloadDto,
        session,
      );

      logger.info("User registered", { userId: newUser?.id });

      // 5. Create user profile
      const userProfileDto = new CreateUserProfileDto({
        userId: newUser?.id as string,
        firstName: dto.firstName,
        lastName: dto.lastName,
      });

      await this.userProfileRepository.create(userProfileDto, session);

      const defaultPlan = await this.resolveDefaultUserPlan();
      if (defaultPlan) {
        await this.subscriptionRepository.create(
          newUser.id as string,
          defaultPlan,
          session,
        );
      }

      await session.commitTransaction();

      const userDto = newUser;

      const token = JwtUtil.sign({
        userId: newUser?.id as string,
        email: newUser?.email as string,
      });

      return {
        ...userDto,
        token,
      };
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      session.endSession();
    }
  }
  async login(dto: TUserLogin): Promise<UserDto> {
    const user = await this.userRepository.findByEmail(dto.email);
    if (!user || !user.password) {
      throw HttpError.unauthorized("Invalid credentials");
    }

    const isPasswordValid = await PasswordUtil.compare(
      dto.password,
      user.password,
    );
    if (!isPasswordValid) {
      throw HttpError.unauthorized("Invalid credentials");
    }

    const userDto = new UserDto(user as any);
    const token = JwtUtil.sign({
      userId: user.id as string,
      email: user.email,
    });

    return { ...userDto, token };
  }

  async forgotPassword(email: string): Promise<any> {
    try {
      const existingUser = await this.userRepository.findByEmail(email);

      if (!existingUser) {
        throw HttpError.badRequest("This email is not registered with us");
      }

      const otp = await otpService.issueOTP(email);
      // tested with welcome mail, send otp here on mail for now , later on whatsapp
      this.emailService.queueOTPEmail(email, otp);
      return {};
    } catch (error) {
      throw error;
    }
  }

  async verifyOTP(email: string, otp: string): Promise<string> {
    try {
      const isValid = await otpService.verifyOTP(email, otp);

      if (!isValid) {
        throw HttpError.unauthorized("Invalid OTP");
      }

      const payload = {
        email: email,
        purpose: "password_reset",
      };

      const expiresIn = "10m";
      const resetToken = JwtUtil.shortLivedToken(payload, expiresIn);
      return resetToken;
    } catch (error) {
      throw error;
    }
  }

  async resetPassword(resetToken: string, newPassword: string): Promise<any> {
    const session = await mongoose.startSession();
    try {
      session.startTransaction();
      let payload: any;
      try {
        payload = JwtUtil.verify(resetToken);
      } catch {
        throw HttpError.unauthorized("Reset link expired or invalid. Please start over.");
      }

      if (payload.purpose !== "password_reset") {
        throw HttpError.unauthorized("Invalid reset token");
      }

      const existingUser = await this.userRepository.findByEmail(payload.email);
      if (!existingUser) {
        throw HttpError.notFound("User not found");
      }

      const hashedPassword = await PasswordUtil.hash(newPassword);
      await this.userRepository.update(
        existingUser.id,
        { password: hashedPassword },
        session,
      );
      await session.commitTransaction();
      return { email: payload.email };
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      session.endSession();
    }
  }

  async findOrCreateGoogleUser(
    authUser: TGoogleUser,
  ): Promise<UserResponseDto> {
    const googleId = authUser.id;
    const email = authUser.emails?.[0]?.value;
    const profilePicture = authUser.photos?.[0]?.value;
    const firstName = authUser.name?.givenName;
    const lastName = authUser.name?.familyName;

    if (!email) throw HttpError.badRequest("Google profile does not contain email");

    // 1. Check if user already registered with this googleId
    let user = await this.userRepository.findByGoogleId(googleId);

    if (user) {
      // User already connected with Google → do NOT update email/googleId
      return new UserResponseDto(user);
    }

    // 2. If googleId not found, check if user exists by email
    user = await this.userRepository.findByEmail(email);

    if (user) {
      // Existing user (ex: team member), but missing googleId
      user = await this.userRepository.update(user?.id as string, {
        email,
        googleId,
      });

      if (!user) throw HttpError.notFound("User not found");
      return new UserResponseDto(user);
    }

    // find role of Admin
    const role = await this.userRepository.findRole("ADMIN");

    // 3. New Google user → create user
    const userData = {
      email,
      googleId,
      role: role?._id,
    };

    // 4. Create user
    const userDataPayloadDto = new CreateUserDto(userData);
    const newUser = await this.userRepository.create(userDataPayloadDto);

    // 5. Create user profile
    const userProfileDto = new CreateUserProfileDto({
      userId: newUser?.id as string,
      profilePicture,
      firstName,
      lastName,
    });

    await this.userProfileRepository.create(userProfileDto);

    const defaultPlan = await this.resolveDefaultUserPlan();
    if (defaultPlan) {
      await this.subscriptionRepository.create(newUser.id as string, defaultPlan);
    }

    this.emailService.queueWelcomeEmail(
      email,
      "https://crm.kyraitsolutions.com/login",
    );

    if (!newUser) throw HttpError.notFound("User not found");

    return new UserResponseDto(newUser);
  }
  async getUserById(id: string): Promise<TUser | null> {
    const user = await this.userRepository.findById(id);
    return user;
  }
  async updateUser(
    id: string,
    data: Partial<TUser>,
    session?: ClientSession,
  ): Promise<UserDto> {
    const user = await this.userRepository.update(id, data, session);

    if (!user) {
      throw HttpError.notFound("User not found");
    }
    return new UserDto(user as any);
  }
  async deleteUser(id: string): Promise<boolean> {
    return this.userRepository.delete(id);
  }
  async generateToken(userId: string, email: string): Promise<string> {
    return JwtUtil.sign({ userId, email });
  }

  private async resolveDefaultUserPlan(): Promise<string | null> {
    const plan =
      (await Plan.findOne({ code: PLAN_CODE.TRIAL })) ||
      (await Plan.findOne({ name: "free" })) ||
      (await Plan.findOne({ code: PLAN_CODE.STARTER }));
    return plan ? String(plan._id) : null;
  }
}
