import { LeadRespository } from "../repositories/lead.respository.js";
import { Lead, LeadModel } from "../models/lead.model.js";
import { GeminiAIUtil } from "../ai/ai.service.js";
import { safeJsonParse } from "../ai/ai.parsers.js";
import { EmailService } from "./email.service.js";
import { LeadDto } from "../dtos/lead.dto.js";
import { ActivityLogService } from "./activityLog.service.js";
import { AutomationEngine } from "./automation-engine.service.js";
import { TActivityLog } from "../types/activityLog.type.js";
import { AUTOMATION_TRIGGERS } from "../constants/automation.constant.js";
import { RequestContext } from "../types/common.js";
import { leadSummaryPrompt } from "../ai/ai.prompts.js";
import { TApiResponse } from "../types/api-response.type.js";
import { ChunkUtil } from "../utils/chunks.util.js";
import { AccountRepository } from "../repositories/account.repository.js";
import { HttpError } from "../utils/http.error.js";
import logger from "../utils/logger.js";
import { ContactService } from "./contact.service.js";
import { ContactRepository } from "../repositories/contact.repository.js";
import { SubscriptionService } from "./subscription.service.js";
import { USAGE_METRIC } from "../constants/subscription.constant.js";
import { notificationService } from "../container.js";
import { emitToAccount } from "../config/wsServer/wsEmitter.js";
import { WEBSOCKET_EVENTS } from "../constants/wsEvent.constants.js";
import { asEntityId } from "../utils/request-context.utils.js";

const BATCH_SIZE = 1000;

export class LeadService {
  private ai: GeminiAIUtil;
  private emailService: EmailService;
  private leadRepository: LeadRespository;
  private automationEngine = new AutomationEngine();
  private activityLogService = new ActivityLogService();
  private accountRepository: AccountRepository;
  private contactService: ContactService;
  private subscriptionService: SubscriptionService;

  constructor() {
    this.ai = new GeminiAIUtil();
    this.emailService = new EmailService();
    this.leadRepository = new LeadRespository();
    this.automationEngine = new AutomationEngine();
    this.activityLogService = new ActivityLogService();
    this.accountRepository = new AccountRepository();
    this.contactService = new ContactService(new ContactRepository());
    this.subscriptionService = new SubscriptionService();
  }

  private async assertLeadCapacity(organizationId?: string) {
    if (!organizationId) return;
    await this.subscriptionService.checkLimit(
      organizationId,
      USAGE_METRIC.LEADS,
    );
  }

  private async recordLeadUsage(organizationId?: string) {
    if (!organizationId) return;
    await this.subscriptionService.recordUsage(
      organizationId,
      USAGE_METRIC.LEADS,
    );
  }

  private contactPayloadFromLead(lead: any) {
    const data = typeof lead?.toJSON === "function" ? lead.toJSON() : lead;
    return {
      accountId: String(data?.accountId || ""),
      name: data?.name,
      email: data?.email,
      phone: data?.phone || data?.mobile,
      mobile: data?.mobile,
      source: data?.source?.name || data?.source,
      tags: data?.tags,
    };
  }

  private async syncContactFromLead(lead: any): Promise<void> {
    await this.contactService.upsertFromLead(this.contactPayloadFromLead(lead));
  }

  async createLeadWs(lead: Lead): Promise<Lead> {
    const account = await this.accountRepository.findOne(String(lead.accountId));
    await this.assertLeadCapacity(account?.organizationId && String(account.organizationId));
    const created = await this.leadRepository.create(lead);
    await this.syncContactFromLead(created);
    await this.recordLeadUsage(account?.organizationId && String(account.organizationId));
    if (account?.organizationId) {
      await this.activityLogService.logCreate({
        accountId: String(lead.accountId),
        organizationId: String(account.organizationId),
        entityType: "lead",
        entityId: String((created as any)?._id || (created as any)?.id),
        actor: { type: "system", name: "chatbot" },
        metadata: {
          leadName: (created as any)?.name,
          source: (created as any)?.source?.name,
        },
      });
    }
    await this.notifyLeadCreated({
      organizationId: asEntityId(account?.organizationId),
      accountId: asEntityId(lead.accountId),
      lead: created,
    });
    return created;
  }
  async createLead(
    context: RequestContext,
    lead: LeadDto,
  ): Promise<TApiResponse<Lead>> {
    logger.info("Creating lead", {
      accountId: context.accountId,
      organizationId: context.organizationId,
    });
    await this.assertLeadCapacity(context.organizationId);
    const result = await this.leadRepository.create(lead);
    await this.syncContactFromLead(result);
    await this.recordLeadUsage(context.organizationId);

    // Activity Log
    const activityLogDataPayload: Partial<TActivityLog> = {
      accountId: String(lead.accountId),
      organizationId: String(context?.organizationId),

      entityType: "lead",
      entityId: String(result._id),

      actor: {
        type: "user",
        id: context.userId,
        name: context.userName,
      },

      metadata: {
        leadName: result?.name,
        source: result?.source?.name,
      },
    };

    await this.activityLogService.logCreate(activityLogDataPayload);

    // Trigger automation
    const automationDataPayload = {
      ...result?.toJSON(),
      organizationId: context?.organizationId,
      entityType: "lead",
      entityId: result._id,
    };

    logger.debug("Lead created, running automations", {
      leadId: String(result._id),
      accountId: result?.accountId,
    });
    await this.automationEngine.process({
      accountId: result?.accountId,
      trigger: AUTOMATION_TRIGGERS.LEAD_CREATED,
      payload: automationDataPayload,
    });

    await this.notifyLeadCreated({
      organizationId: asEntityId(context.organizationId),
      accountId: asEntityId(lead.accountId || result?.accountId),
      lead: result,
    });

    return {
      doc: result,
    };
  }

  private buildBulkOps(
    context: RequestContext,
    leads: LeadDto[],
    uniqueKey: string,
    mode: "upsert" | "insert" | "skip",
  ) {
    return leads.map((lead) => {
      const doc = {
        ...lead,
        accountId: context.accountId,
        organizationId: context.organizationId,
      };

      if (mode === "upsert" && uniqueKey) {
        return {
          updateOne: {
            filter: {
              accountId: context.accountId,
              [uniqueKey]: (lead as any)[uniqueKey],
            },
            update: { $set: doc },
            upsert: true,
          },
        };
      }

      return { insertOne: { document: doc } };
    });
  }

  async createBulkLead(
    context: RequestContext,
    leads: LeadDto[],
    uniqueKey: string,
    mode: any,
  ): Promise<any> {
    
    if (!Array.isArray(leads) || leads.length === 0) {
      throw HttpError.badRequest("leads must be a non-empty array");
    }

    const results = { inserted: 0, updated: 0, failed: 0, errors: [] as any[] };
    const batches = ChunkUtil.chunkArray(leads, BATCH_SIZE);

    logger.info("Bulk lead write started", {
      batches: batches.length,
      uniqueKey,
      mode,
    });
    for (let i = 0; i < batches.length; i++) {
      const ops = this.buildBulkOps(context, batches[i], uniqueKey, mode);
      const offset = i * BATCH_SIZE;

      try {
        const res = await this.leadRepository.bulkWrite(ops);
        results.inserted += res.insertedCount + res.upsertedCount;
        results.updated += res.modifiedCount;
        await this.contactService.upsertManyFromLeads(
          batches[i].map((lead) =>
            this.contactPayloadFromLead({
              ...lead,
              accountId: context.accountId,
            }),
          ),
        );
      } catch (err: any) {
        const writeErrors = err?.writeErrors || [];
        results.failed += writeErrors.length;
        results.inserted += (err?.result?.insertedCount || 0) + (err?.result?.upsertedCount || 0);
        results.updated += err?.result?.modifiedCount || 0;
        results.errors.push(
          ...writeErrors.map((e: any) => ({
            index: offset + e.index,
            message: e.errmsg,
          })),
        );
      }
    }
    return results;
  }

  async getLeads(_userId: string,accountId: string,payload: Record<string, any>,skip: number): Promise<any | null> {
    if (!accountId) {
      throw HttpError.badRequest("Account id is required");
    }
    const {
      page = 1,
      limit = 10,
      search,
      filters = {},
      assignedTo,
      form,
      dateRange,
      read,
      sort = {},
    } = payload;
    console.log(page, read);
    const criteria: any = {
      // userId,
      accountId,
    };

    // SEARCH===============================================
    if (search?.trim()) {
      criteria.$or = [
        {
          name: {
            $regex: search,
            $options: "i",
          },
        },
        {
          email: {
            $regex: search,
            $options: "i",
          },
        },
        {
          phone: {
            $regex: search,
            $options: "i",
          },
        },
        {
          company: {
            $regex: search,
            $options: "i",
          },
        },
      ];
    }
    // FILTERS===================================

    if (filters.stage) {
      criteria.stage = filters.stage;
    }

    if (filters.status) {
      criteria.status = filters.status;
    }

    if (filters.source) {
      criteria["source.name"] = filters.source;
    }

    // assignedTo
    if (assignedTo) {
      criteria.assignedTo = assignedTo;
    }

    // form
    if (form) {
      criteria["source.formId"] = form;
    }

    // tags
    if (filters.tags?.length) {
      criteria.tags = {
        $in: filters.tags,
      };
    }

    // DATE RANGE
    // -------------------------
    if (dateRange?.startDate && dateRange?.endDate) {
      const start = new Date(dateRange.startDate);
      const end = new Date(dateRange.endDate);
      if (
        end.getUTCHours() === 0 &&
        end.getUTCMinutes() === 0 &&
        end.getUTCSeconds() === 0 &&
        end.getUTCMilliseconds() === 0
      ) {
        end.setUTCHours(23, 59, 59, 999);
      }
      criteria.createdAt = {
        $gte: start,
        $lte: end,
      };
    }

    // SORTING
    // -------------------------
    const sortQuery: any = {};

    if (sort?.field) {
      sortQuery[sort.field] = sort.order === "asc" ? 1 : -1;
    } else {
      sortQuery.createdAt = -1;
    }

    return await Promise.all([
      this.leadRepository.find(criteria, limit, skip, sortQuery),
      this.leadRepository.countDocuments(criteria),
    ]);
    // const leads = await this.leadRepository.find(criteria, paginationOptions);

    // return {
    //   leads:leads||[],
    //   totalDocs: count,
    // };
  }
  async getLead(accountId: string, leadId: string): Promise<any | null> {
    return await this.leadRepository.getLeadById(accountId, leadId);
  }
  async getLeadSummary(accountId: string, leadId: string): Promise<any> {
    const lead = await this.leadRepository.getLeadById(accountId, leadId);

    // For Gemini
    const prompt = leadSummaryPrompt(lead);
    const rawResponse = await this.ai.runGoogleAI({ prompt });

    // For Open AI
    // const prompt = JSON.stringify(lead);
    // const rawResponse = await this.ai.runOpenAI(
    //   prompt,
    //   "one parameter expected here",
    // );
    logger.debug("Lead summary generated", { accountId, leadId });

    if (!rawResponse) {
      return null;
    }
    const result = safeJsonParse(rawResponse);
    return result;
  }

  // async updateLead(
  //   _accountId: string,
  //   leadId: string,
  //   lead: Lead,
  // ): Promise<Lead | null> {
  //   const existingLead = await this.leadRepository.getLeadById(
  //     _accountId,
  //     leadId,
  //   );

  //   if (!existingLead) {
  //     throw HttpError.notFound("Lead not found");
  //   }

  //   const updatedLead = await this.leadRepository.updateLeadById(leadId, lead);

  //   if (existingLead?.stage && existingLead?.stage !== updatedLead?.stage) {
  //     this.AutomationEngine.process({
  //       accountId: _accountId,
  //       trigger: "lead-status-changed",
  //       payload: updatedLead,
  //     });
  //   }

  //   return updatedLead;
  // }

  async updateLead(
    accountId: string,
    leadId: string,
    lead: Lead,
    currentUser: any,
  ): Promise<TApiResponse<Lead | null>> {
    const existingLead = await this.leadRepository.getLeadById(
      accountId,
      leadId,
    );

    if (!existingLead) {
      throw HttpError.notFound("Lead not found");
    }

    const updateData: Record<string, any> = {};
    const customFields: Record<string, any> = {};

    // const schemaPaths = Object.keys(LeadModel.schema.paths);

    for (const [key, value] of Object.entries(lead)) {
      // protected fields
      if (["_id", "id", "createdAt", "updatedAt"].includes(key)) {
        continue;
      }

      // schema field exists
      if (LeadModel.schema.path(key)) {
        updateData[key] = value;
      } else {
        customFields[key] = value;
      }
    }

    const updatedLead = await this.leadRepository.updateLeadById(leadId, lead);
    await this.syncContactFromLead({
      ...existingLead,
      ...updatedLead,
      accountId,
    });

    await this.activityLogService.logUpdate({
      accountId: accountId,
      organizationId: currentUser?.organizationId,

      entityType: "lead",
      entityId: leadId,

      action: "lead.updated",

      actor: {
        type: "user",
        name: currentUser.name,
        id: currentUser.id,
      },

      metadata: {
        leadName: updatedLead?.name,
        source: updatedLead?.source?.name,
      },

      oldDoc: existingLead,
      newDoc: updatedLead,
    });

    return {
      doc: updatedLead,
    };
  }
  async updateLeadWs(lead: Lead): Promise<Lead | null> {
    const updated = await this.leadRepository.update(lead);
    if (updated) {
      await this.syncContactFromLead(updated);
    }
    return updated;
  }

  private async notifyLeadCreated({
    organizationId,
    accountId,
    lead,
  }: {
    organizationId: string;
    accountId: string;
    lead: any;
  }) {
    try {
      const data = typeof lead?.toJSON === "function" ? lead.toJSON() : lead;
      const leadId = asEntityId(data?.id || data?._id || lead?._id);
      await notificationService.notifyNewLead({
        organizationId: asEntityId(organizationId),
        accountId: asEntityId(accountId),
        leadId,
        name: data?.name,
        phone: data?.phone || data?.mobile,
        email: data?.email,
        source: data?.source?.name || data?.source,
      });
      emitToAccount(asEntityId(accountId), WEBSOCKET_EVENTS["Chatbot Lead Created"], {
        lead: data,
      });
    } catch (error) {
      logger.warn("Failed to emit lead notification", {
        accountId,
        error: (error as Error).message,
      });
    }
  }

  async notifyLeadUpdated(lead: Lead | null): Promise<void> {
    if (!lead?.name || !lead.phone || !lead.email) {
      return;
    }

    const account = await this.accountRepository.findOne(
      String(lead.accountId),
    );

    const leadPayload = {
      ...lead,
      accountName: account?.accountName,
      supportEmail: account?.email,
    };

    logger.info("Queueing lead acknowledgement email", {
      email: leadPayload.email,
      accountId: lead.accountId,
    });

    await this.emailService.queueLeadAcknowledgementEmail(
      leadPayload.email as string,
      leadPayload,
    );
  }
}

//  async updateLead(
//     accountId: string,
//     leadId: string,
//     lead: Partial<Lead>,
//     currentUserId: string,
//   ): Promise<Lead> {
//     const existingLead = await this.leadRepository.getLeadById(
//       accountId,
//       leadId,
//     );

//     if (!existingLead) {
//       throw HttpError.notFound("Lead not found");
//     }

//     const changes = {
//       stageChanged: lead.stage && existingLead.stage !== lead.stage,
//       statusChanged: lead.status && existingLead.status !== lead.status,
//       assigneeChanged:
//         lead.assignment?.assignedTo &&
//         String(existingLead.assignment?.assignedTo) !==
//           String(lead.assignment.assignedTo),
//     };

//     if (changes.assigneeChanged) {
//       lead.assignment = {
//         assignedTo: lead.assignment!.assignedTo,
//         assignedAt: new Date(),
//         assignedBy: currentUserId,
//         assignmentType: "manual",
//       };
//     }

//     const updatedLead = await this.leadRepository.updateLeadById(leadId, lead);

//     // await this.createLeadActivities(existingLead, updatedLead, currentUserId);

//     const triggers = [];

//     if (changes.stageChanged) {
//       triggers.push("lead-stage-changed");
//     }

//     if (changes.statusChanged) {
//       triggers.push("lead-status-changed");
//     }

//     if (changes.assigneeChanged) {
//       triggers.push("lead-assigned");
//     }

//     await Promise.all(
//       triggers.map((trigger) =>
//         this.AutomationEngine.process({
//           accountId,
//           trigger,
//           payload: updatedLead,
//         }),
//       ),
//     );

//     return updatedLead;
//   }
