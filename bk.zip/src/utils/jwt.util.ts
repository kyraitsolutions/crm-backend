import jwt from "jsonwebtoken";
import { ENV } from "../constants/env.constants.js";

export interface JwtPayload {
  userId: string;
  email: string;
}
export interface ShortJwtPayload {
  email: string;
  purpose: string;
}

export class JwtUtil {
  private static readonly SECRET = ENV.AUTH.JWT_SECRET || "default-secret";
  private static readonly EXPIRES_IN = "7d";

  static sign(payload: JwtPayload): string {
    return jwt.sign(payload, this.SECRET, { expiresIn: this.EXPIRES_IN });
  }
  static inviteToken(payload: any): string {
    return jwt.sign(payload, this.SECRET, { expiresIn: this.EXPIRES_IN });
  }

  static verify(token: string): JwtPayload {
    return jwt.verify(token, this.SECRET) as JwtPayload;
  }

  static shortLivedToken(payload: ShortJwtPayload, ttl: string) {
    return jwt.sign(payload, this.SECRET, { expiresIn: this.EXPIRES_IN });
  }

  static decode(token: string): JwtPayload | null {
    return jwt.decode(token) as JwtPayload | null;
  }
}
