import { Router } from "express";
import { IntegrationController } from "../controllers/integration.controller.js";
import { AuthMiddleware } from "../../../middleware/auth.middleware.js";

export class IntegrationRouter {
  public router: Router;
  private integrationController = new IntegrationController();

  constructor() {
    this.router = Router();
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(
      "/:accountId/:provider",
      AuthMiddleware.authenticate,
      this.integrationController.getIntegration.bind(
        this.integrationController,
      ),
    );
  }

  public getRouter(): Router {
    return this.router;
  }
}
