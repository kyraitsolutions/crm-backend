import { ENV } from "../constants/index.js";

export const config = {
  app: {
    port: Number(ENV.APP.PORT) || 3000,
  },

  auth: {
    jwtSecret: ENV.AUTH.JWT_SECRET as string,
    jwtExpiresIn: ENV.AUTH.JWT_EXPIRES_IN,
  },

  db: {
    url: ENV.DB.DATABASE_URL,
  },

  google: {
    clientId: ENV.GOOGLE.CLIENT_ID,
    clientSecret: ENV.GOOGLE.CLIENT_SECRET,
    callbackUrl:
      ENV.GOOGLE.CALLBACK_URL ||
      "http://localhost:3000/api/auth/google/callback",
  },

  meta: {
    APP_ID: ENV.META.APP_ID,
    APP_SECRET: ENV.META.APP_SECRET,
    GRAPH_BASE_URL: ENV.META.GRAPH_BASE_URL,
    GRAPH_VERSION: ENV.META.GRAPH_VERSION,
    REDIRECT_URI: ENV.META.REDIRECT_URI,
    VERIFY_WEBHOOK_TOKEN: ENV.META.VERIFY_WEBHOOK_TOKEN,
  },

  aws: {
    cdnDomain: ENV.AWS.CDN_DOMAIN,
    region: ENV.AWS.REGION,
    bucket: ENV.AWS.S3_BUCKET,
    accessKeyId: ENV.AWS.ACCESS_KEY_ID,
    secretAccessKey: ENV.AWS.SECRET_KEY,
  },

  cross_domains: {
    origin: ENV.CROSS_DOMAIN.ORIGIN?.split(",").map((o: string) => o.trim()),
  },

  redis: {
    host: ENV.REDIS.REDIS_HOST,
    port: Number(ENV.REDIS.REDIS_PORT),
    pass: ENV.REDIS.REDIS_PASS,
  },

  razorpay: {
    keyId: ENV.RAZORPAY.KEY_ID,
    keySecret: ENV.RAZORPAY.KEY_SECRET,
    webhookSecret: ENV.RAZORPAY.WEBHOOK_SECRET,
  },
};
